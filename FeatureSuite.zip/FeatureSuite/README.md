# FeatureSuite — Modular Paper 1.21.11 Plugin

A toggle-everything admin / recording / SMP-utility suite built around one
core idea: **every feature is a self-contained module that the `/features`
GUI can enable or disable live**, with zero server restart and immediate
`config.yml` persistence.

## What's actually implemented here

This scaffold delivers exactly the four things asked for, fully working:

| # | Deliverable | File(s) |
|---|---|---|
| 1 | Main class + lifecycle + module registry | `PluginMain.java` |
| 2 | `FeatureManager` (register/toggle/GUI wiring) | `module/FeatureManager.java`, `gui/FeatureGUI.java` |
| 3 | Two fully working example modules | `module/impl/RecordingSessionModule.java`, `module/impl/VanishModule.java` |
| 4 | `plugin.yml` + `config.yml` boilerplate | `src/main/resources/*.yml` |

The other ~18 modules from the spec (Server Lock, Sudo, Invsee, Kits, Item
Maker, Stasis Rod, etc.) are **wired into `plugin.yml`, `config.yml`, and
the permission list already**, and `PluginMain` has a commented-out
registration line for each — because the manager/GUI are fully generic,
adding one is copy-paste-implement, not new plumbing. See "Adding a new
module" below.

## Why it's structured this way

- **`FeatureModule` is the only contract that matters.** The GUI, the
  toggle command, and the persistence layer all talk to modules through
  this interface — never to a concrete class. That's what makes "click to
  disable" also mean "listener actually unregisters" instead of just
  flipping a cosmetic boolean.
- **Disabled really means disabled.** `FeatureManager` calls
  `HandlerList.unregisterAll(listener)` for every listener a module
  reports, and `CommandRegistrar` rips the command back out of the live
  `CommandMap` via reflection (the standard, widely-used Bukkit trick for
  runtime command registration — there's no public API for it). A disabled
  module costs nothing at runtime, not even a "feature is off" branch
  inside a hot listener.
- **One file per module.** `RecordingSessionModule` and `VanishModule`
  each bundle their command executor and listener as inner classes. No
  hunting across five files to understand one feature.
- **Config is additive.** `FeatureManager.register()` reads
  `modules.<id>.enabled` with a safe default, so shipping a new module
  version never requires a config migration for existing servers.

## Adding a new module

1. Create `module/impl/YourModule.java extends AbstractFeatureModule`,
   implementing `onEnable()`, `onDisable()`, `getListeners()`,
   `getExecutor()` — pattern-match `VanishModule` for something with a
   listener + command, or `RecordingSessionModule` for something more
   config-driven.
2. Add its command(s) under `commands:` in `plugin.yml` (required —
   `CommandRegistrar` only binds to commands Bukkit already knows about; it
   doesn't fabricate new ones) and a `plugin.feature.<x>` permission node.
3. Add a `modules.<id>` block to `config.yml` (at minimum, `enabled: false`
   plus whatever settings your module reads).
4. Uncomment/add its line in `PluginMain#onEnable()`:
   `featureManager.register(new YourModule(this));`

That's the entire integration surface. No touching `FeatureManager` or
`FeatureGUI`.

## Permission model

- `plugin.admin` — full bypass, can open `/features` and toggle/use every
  module regardless of individual nodes.
- `plugin.feature.<name>` — grants use of one module's command(s) and lets
  a non-admin see/toggle just that tile in the GUI (the GUI currently shows
  all tiles to anyone who can open it — restrict `plugin.admin` on the
  `/features` command itself if you want a strictly admin-only panel, or
  extend `FeatureGUI.build()` to filter tiles by `getPermission()` per
  viewer).

## Build

Requires JDK 21 and Maven.

```bash
mvn clean package
```

The shaded/plain jar lands in `target/FeatureSuite-1.0.0.jar`. Drop it in
`plugins/` on a Paper 1.21.11 server. `config.yml` and `plugin.yml` are
pulled from `src/main/resources` automatically by `saveDefaultConfig()`.

## Notes / things to harden before production

- `CommandRegistrar` uses reflection on Bukkit's internal `CommandMap` /
  `knownCommands` field. This is the standard approach every major plugin
  (LuckPerms, EssentialsX, etc.) uses for runtime command
  registration/unregistration, but field names are Bukkit-internal and
  could theoretically shift between server jar builds — pin your Paper
  build and add a CI smoke test that boots the plugin.
- `VanishModule`'s tab-list hiding relies on `Player#hidePlayer` /
  `Player#setPlayerListName`; for a fully packet-level vanish (hidden from
  `/list`, plugin-msg-based radar minigames, etc.) you'd add a
  `PlayerListHeaderFooter`/PlayerInfo packet layer via Paper's newer
  entity-visibility API.
- `RecordingSessionModule`'s coordinate redaction is a regex heuristic —
  good enough to stop accidental "I'm at 123, 64, -789" chat leaks on
  stream, not a security boundary.
- Modules that need cross-module data (e.g. Kits needing Item Maker's
  serialization format) should talk through `PluginMain#getFeatureManager()
  .get("itemmaker")` and a small shared interface, not by importing each
  other's impl classes directly.
