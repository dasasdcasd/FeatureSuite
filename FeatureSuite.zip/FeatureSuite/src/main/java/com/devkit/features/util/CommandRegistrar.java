package com.devkit.features.util;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandMap;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

/**
 * Binds/unbinds the {@link PluginCommand}s that plugin.yml already declared
 * to a live {@link CommandExecutor}, and can fully unregister a command from
 * the server's {@link CommandMap} so a disabled module truly disappears
 * (no "unknown command" fallback still routing into dead code, and the
 * command no longer tab-completes).
 * <p>
 * Every command used here MUST already exist in plugin.yml; this class does
 * not fabricate new commands, it only toggles their live binding, which
 * keeps behaviour predictable and avoids leaking synthetic Command objects
 * that never get cleaned up.
 */
public final class CommandRegistrar {

    private final Plugin plugin;
    private final CommandMap commandMap;
    private final Map<String, Command> knownCommandsSnapshot;

    @SuppressWarnings("unchecked")
    public CommandRegistrar(Plugin plugin) {
        this.plugin = plugin;
        CommandMap map;
        Map<String, Command> knownCommands;
        try {
            Field commandMapField = Bukkit.getServer().getClass().getDeclaredField("commandMap");
            commandMapField.setAccessible(true);
            map = (CommandMap) commandMapField.get(Bukkit.getServer());

            Field knownCommandsField = map.getClass().getDeclaredField("knownCommands");
            knownCommandsField.setAccessible(true);
            knownCommands = (Map<String, Command>) knownCommandsField.get(map);
        } catch (ReflectiveOperationException ex) {
            plugin.getLogger().log(Level.SEVERE, "Failed to hook the server CommandMap - dynamic "
                    + "command (un)registration will not work on this server build.", ex);
            map = null;
            knownCommands = new HashMap<>();
        }
        this.commandMap = map;
        this.knownCommandsSnapshot = knownCommands;
    }

    /**
     * Binds the given executor (and tab completer, if it implements one) to
     * the plugin.yml-declared command {@code name}, and re-inserts it into
     * the CommandMap under the plugin's fallback prefix and its own name so
     * it works even if a previous disable() removed it.
     */
    public void bind(String name, CommandExecutor executor) {
        if (name == null || name.isBlank()) return;

        PluginCommand command = Bukkit.getPluginCommand(name);
        if (command == null) {
            command = constructPluginCommand(name);
        }
        if (command == null) {
            plugin.getLogger().warning("Cannot bind command '" + name + "' - it is not declared in plugin.yml.");
            return;
        }

        command.setExecutor(executor);
        if (executor instanceof TabCompleter tc) {
            command.setTabCompleter(tc);
        }

        if (commandMap != null) {
            commandMap.register(plugin.getName().toLowerCase(), command);
        }
    }

    /**
     * Fully removes the command from the CommandMap so it no longer
     * resolves at all while its owning module is disabled.
     */
    public void unbind(String name) {
        if (name == null || name.isBlank() || knownCommandsSnapshot == null) return;

        knownCommandsSnapshot.remove(name.toLowerCase());
        knownCommandsSnapshot.remove(plugin.getName().toLowerCase() + ":" + name.toLowerCase());
    }

    private PluginCommand constructPluginCommand(String name) {
        try {
            Constructor<PluginCommand> ctor = PluginCommand.class.getDeclaredConstructor(String.class, Plugin.class);
            ctor.setAccessible(true);
            return ctor.newInstance(name, plugin);
        } catch (ReflectiveOperationException ex) {
            plugin.getLogger().log(Level.SEVERE, "Failed to construct PluginCommand for '" + name + "'", ex);
            return null;
        }
    }
}
