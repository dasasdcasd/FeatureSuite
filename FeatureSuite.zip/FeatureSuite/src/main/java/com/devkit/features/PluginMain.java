package com.devkit.features;

import com.devkit.features.gui.FeatureGUI;
import com.devkit.features.module.FeatureManager;
import com.devkit.features.module.impl.RecordingSessionModule;
import com.devkit.features.module.impl.VanishModule;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Entry point. Keeps startup boring on purpose: load config, build the
 * manager, register every module, bind the GUI command, done. All the
 * interesting behaviour lives inside individual modules so this class never
 * has to grow as the module count grows.
 * <p>
 * To add a new module:
 * <ol>
 *     <li>Create a class in {@code module.impl} extending {@code AbstractFeatureModule}</li>
 *     <li>Add its command(s) to plugin.yml and its config block to config.yml</li>
 *     <li>Register it with {@code featureManager.register(new YourModule(this))} below</li>
 * </ol>
 * Nothing else needs to change - the GUI, the toggle persistence, and the
 * live listener/command (un)binding are all driven generically off the
 * {@link com.devkit.features.module.FeatureModule} interface.
 */
public final class PluginMain extends JavaPlugin {

    private FeatureManager featureManager;
    private NamespacedKey moduleIdKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.moduleIdKey = new NamespacedKey(this, "feature_module_id");
        this.featureManager = new FeatureManager(this);

        // --- Core two fully-implemented example modules (see deliverable #3) ---
        featureManager.register(new RecordingSessionModule(this));
        featureManager.register(new VanishModule(this));

        // --- Everything else listed in the spec plugs in the exact same way. ---
        // Uncomment / implement as each module is built out; the manager,
        // GUI, and permission/config wiring already support them:
        //
        // featureManager.register(new ServerLockModule(this));
        // featureManager.register(new CommandBlockerModule(this));
        // featureManager.register(new ChatFilterModule(this));
        // featureManager.register(new DimensionLockModule(this));
        // featureManager.register(new FakeWorldBorderModule(this));
        // featureManager.register(new SudoModule(this));
        // featureManager.register(new AutoClearModule(this));
        // featureManager.register(new FakeEventsModule(this));       // fakejoin/leave/death
        // featureManager.register(new HalfHeartProtectionModule(this));
        // featureManager.register(new KeepInventoryModule(this));
        // featureManager.register(new VoiceChatModule(this));        // /vcmute via SVC API
        // featureManager.register(new InvseeModule(this));           // invsee + endersee
        // featureManager.register(new WarpsModule(this));            // warp/otp/top
        // featureManager.register(new NickSkinModule(this));
        // featureManager.register(new ItemMakerModule(this));
        // featureManager.register(new CombatItemsModule(this));      // stasis rod, orbital strike
        // featureManager.register(new NpcModule(this));              // npc + villager
        // featureManager.register(new KitsModule(this));

        FeatureGUI gui = new FeatureGUI(this, featureManager);
        getServer().getPluginManager().registerEvents(gui, this);
        var featuresCommand = getCommand("features");
        if (featuresCommand != null) {
            featuresCommand.setExecutor(gui);
        } else {
            getLogger().severe("The 'features' command is missing from plugin.yml!");
        }

        getLogger().info("FeatureSuite enabled with " + featureManager.getModules().size() + " module(s) registered.");
    }

    @Override
    public void onDisable() {
        if (featureManager != null) {
            featureManager.shutdown();
        }
    }

    public FeatureManager getFeatureManager() {
        return featureManager;
    }

    /** Shared key used to tag GUI buttons with the module id they represent. */
    public NamespacedKey getModuleIdKey() {
        return moduleIdKey;
    }
}
