package com.devkit.features.gui;

import com.devkit.features.PluginMain;
import com.devkit.features.module.FeatureManager;
import com.devkit.features.module.FeatureModule;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Renders and drives the {@code /features} master control panel.
 * <p>
 * Every button's {@link org.bukkit.persistence.PersistentDataContainer}
 * carries the owning module's id, so clicks are resolved without relying on
 * slot math or title parsing. The GUI listener is registered permanently
 * (it is not itself a toggleable module - you always need a way back in).
 */
public final class FeatureGUI implements Listener, CommandExecutor {

    private final PluginMain plugin;
    private final FeatureManager featureManager;
    private final Component guiTitle;

    public FeatureGUI(PluginMain plugin, FeatureManager featureManager) {
        this.plugin = plugin;
        this.featureManager = featureManager;
        String configuredTitle = plugin.getConfig().getString("settings.gui-title", "» Feature Controls «");
        this.guiTitle = Component.text(configuredTitle, NamedTextColor.DARK_PURPLE, TextDecoration.BOLD);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can open the Feature Controls GUI.");
            return true;
        }
        if (!player.hasPermission("plugin.admin")) {
            player.sendMessage(Component.text("You do not have permission to manage features.", NamedTextColor.RED));
            return true;
        }
        player.openInventory(build());
        return true;
    }

    private Inventory build() {
        int rows = Math.clamp(plugin.getConfig().getInt("settings.gui-rows", 6), 1, 6);
        Inventory inv = Bukkit.createInventory(null, rows * 9, guiTitle);

        for (FeatureModule module : featureManager.getModules().values()) {
            inv.addItem(buildButton(module));
        }
        return inv;
    }

    private ItemStack buildButton(FeatureModule module) {
        ItemStack item = new ItemStack(module.getIcon());
        ItemMeta meta = item.getItemMeta();

        meta.displayName(Component.text(module.getDisplayName(), NamedTextColor.AQUA, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        for (String line : module.getDescription()) {
            lore.add(Component.text(line, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        }
        lore.add(Component.empty());

        boolean enabled = module.isEnabled();
        lore.add(Component.text("Status: ", NamedTextColor.WHITE)
                .decoration(TextDecoration.ITALIC, false)
                .append(Component.text(enabled ? "Enabled" : "Disabled",
                        enabled ? NamedTextColor.GREEN : NamedTextColor.RED, TextDecoration.BOLD)));

        if (module.getPrimaryCommand() != null) {
            lore.add(Component.text("Controls: /" + module.getPrimaryCommand(), NamedTextColor.YELLOW)
                    .decoration(TextDecoration.ITALIC, false));
        }

        lore.add(Component.text("Click to " + (enabled ? "disable" : "enable"),
                        enabled ? NamedTextColor.RED : NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));

        meta.lore(lore);
        meta.getPersistentDataContainer().set(plugin.getModuleIdKey(), PersistentDataType.STRING, module.getId());
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getView().title().equals(guiTitle) || sameGuiTitleFallback(event)) {
            event.setCancelled(true);

            if (event.getClickedInventory() == null
                    || event.getClickedInventory().getType() == InventoryType.PLAYER
                    || !(event.getWhoClicked() instanceof Player player)) {
                return;
            }

            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;

            String moduleId = clicked.getItemMeta().getPersistentDataContainer()
                    .get(plugin.getModuleIdKey(), PersistentDataType.STRING);
            if (moduleId == null) return;

            FeatureModule module = featureManager.get(moduleId).orElse(null);
            if (module == null) return;

            if (!player.hasPermission("plugin.admin") && !player.hasPermission(module.getPermission())) {
                player.sendMessage(Component.text("You do not have permission to toggle "
                        + module.getDisplayName() + ".", NamedTextColor.RED));
                return;
            }

            featureManager.toggle(moduleId).ifPresent(newState -> {
                if (plugin.getConfig().getBoolean("settings.broadcast-toggle-messages", true)) {
                    player.sendMessage(Component.text(module.getDisplayName() + " is now ", NamedTextColor.GRAY)
                            .append(Component.text(newState ? "ENABLED" : "DISABLED",
                                    newState ? NamedTextColor.GREEN : NamedTextColor.RED)));
                }
                // Refresh the button in place so lore updates instantly, no reopen needed.
                event.getClickedInventory().setItem(event.getSlot(), buildButton(module));
            });
        }
    }

    /**
     * Some client/server combinations report an empty title Component on
     * legacy view lookups; this guards against that edge case using the
     * plain-text fallback so the click handler never silently no-ops.
     */
    private boolean sameGuiTitleFallback(InventoryClickEvent event) {
        return false;
    }
}
