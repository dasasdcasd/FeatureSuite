package com.devkit.features.module;

import org.bukkit.Material;
import org.bukkit.event.Listener;

import java.util.List;

/**
 * Contract implemented by every toggleable feature in the suite.
 * <p>
 * A module owns exactly one config block under {@code modules.<id>} and,
 * optionally, one or more Bukkit commands and listeners. The
 * {@link com.devkit.features.module.FeatureManager} is solely responsible
 * for flipping {@link #onEnable()}/{@link #onDisable()} and for wiring the
 * listeners/commands the module reports, so implementations should never
 * register themselves directly with Bukkit.
 */
public interface FeatureModule {

    /** Unique, lowercase, config-safe identifier, e.g. {@code "vanish"}. */
    String getId();

    /** Human-readable name shown in the GUI, e.g. {@code "Vanish"}. */
    String getDisplayName();

    /** Short lore description shown under the status line in the GUI. */
    List<String> getDescription();

    /** Icon material for the GUI button. */
    Material getIcon();

    /**
     * Primary player-facing command this module owns (without the slash),
     * or {@code null} if it exposes no command. Must match a key under
     * {@code commands:} in plugin.yml.
     */
    String getPrimaryCommand();

    /** Permission node required to use this module, e.g. {@code plugin.feature.vanish}. */
    String getPermission();

    /**
     * Called by the manager immediately after the module is marked enabled
     * and the config flag has been persisted. Implementations should do any
     * one-time setup here (schedulers, warm caches, etc). Listener and
     * command (de)registration is handled automatically by the manager
     * using {@link #getListeners()} and {@link #getExecutor()} - do not
     * call {@code registerEvents} yourself.
     */
    void onEnable();

    /**
     * Called by the manager immediately after the module is marked
     * disabled. Implementations should cancel any running tasks and drop
     * transient state (e.g. clear vanished-player sets) so re-enabling
     * starts clean.
     */
    void onDisable();

    /** Listeners this module wants registered while enabled. Empty list if none. */
    List<Listener> getListeners();

    /**
     * The command executor (and, if applicable, tab completer) backing
     * {@link #getPrimaryCommand()} and any secondary commands returned by
     * {@link #getSecondaryCommands()}. May be {@code null} if the module
     * has no command.
     */
    Object getExecutor();

    /** Extra commands (besides {@link #getPrimaryCommand()}) this module owns. Empty by default. */
    default List<String> getSecondaryCommands() {
        return List.of();
    }

    boolean isEnabled();

    void setEnabledState(boolean enabled);
}
