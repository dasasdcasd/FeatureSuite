package com.devkit.features.module;

import com.devkit.features.PluginMain;
import org.bukkit.Material;
import org.bukkit.event.Listener;

import java.util.List;

/**
 * Convenience base class that stores the common fields every module needs
 * and leaves only the feature-specific behaviour to subclasses.
 */
public abstract class AbstractFeatureModule implements FeatureModule {

    protected final PluginMain plugin;
    private final String id;
    private final String displayName;
    private final List<String> description;
    private final Material icon;
    private final String primaryCommand;
    private final String permission;

    private volatile boolean enabled;

    protected AbstractFeatureModule(PluginMain plugin, String id, String displayName,
                                     List<String> description, Material icon,
                                     String primaryCommand, String permission) {
        this.plugin = plugin;
        this.id = id;
        this.displayName = displayName;
        this.description = description;
        this.icon = icon;
        this.primaryCommand = primaryCommand;
        this.permission = permission;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getDisplayName() {
        return displayName;
    }

    @Override
    public List<String> getDescription() {
        return description;
    }

    @Override
    public Material getIcon() {
        return icon;
    }

    @Override
    public String getPrimaryCommand() {
        return primaryCommand;
    }

    @Override
    public String getPermission() {
        return permission;
    }

    @Override
    public List<Listener> getListeners() {
        return List.of();
    }

    @Override
    public Object getExecutor() {
        return null;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void setEnabledState(boolean enabled) {
        this.enabled = enabled;
    }
}
