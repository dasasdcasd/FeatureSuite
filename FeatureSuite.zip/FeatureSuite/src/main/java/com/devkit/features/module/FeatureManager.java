package com.devkit.features.module;

import com.devkit.features.PluginMain;
import com.devkit.features.util.CommandRegistrar;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Level;

/**
 * Central registry for every {@link FeatureModule}. Responsible for:
 * <ul>
 *     <li>Loading each module's {@code enabled} flag out of config.yml on boot</li>
 *     <li>Wiring/unwiring listeners and commands the instant a module is toggled</li>
 *     <li>Persisting toggles back to config.yml immediately (no manual /reload needed)</li>
 * </ul>
 * This is the single source of truth the {@code /features} GUI reads and writes through.
 */
public final class FeatureManager {

    private final PluginMain plugin;
    private final CommandRegistrar commandRegistrar;
    private final Map<String, FeatureModule> modules = new LinkedHashMap<>();

    public FeatureManager(PluginMain plugin) {
        this.plugin = plugin;
        this.commandRegistrar = new CommandRegistrar(plugin);
    }

    /**
     * Registers a module with the manager and immediately activates it if
     * its config flag (or the default baked into the module) says enabled.
     * Call this once per module during {@link PluginMain#onEnable()}.
     */
    public void register(FeatureModule module) {
        if (modules.containsKey(module.getId())) {
            throw new IllegalStateException("Duplicate module id registered: " + module.getId());
        }
        modules.put(module.getId(), module);

        boolean configuredEnabled = plugin.getConfig()
                .getBoolean("modules." + module.getId() + ".enabled", false);
        module.setEnabledState(false); // start neutral; apply() below flips it live
        applyState(module, configuredEnabled, false);
    }

    /** Toggles a module by id. Returns the new state, or empty if no such module exists. */
    public Optional<Boolean> toggle(String id) {
        FeatureModule module = modules.get(id);
        if (module == null) return Optional.empty();
        boolean newState = !module.isEnabled();
        applyState(module, newState, true);
        return Optional.of(newState);
    }

    public void setEnabled(String id, boolean enabled) {
        FeatureModule module = modules.get(id);
        if (module != null) applyState(module, enabled, true);
    }

    private void applyState(FeatureModule module, boolean enabled, boolean persist) {
        boolean wasEnabled = module.isEnabled();
        if (wasEnabled == enabled) {
            return; // no-op, avoids double-registering listeners
        }

        try {
            if (enabled) {
                module.setEnabledState(true);
                module.onEnable();
                registerListeners(module);
                registerCommands(module);
            } else {
                unregisterCommands(module);
                unregisterListeners(module);
                module.onDisable();
                module.setEnabledState(false);
            }
        } catch (Exception ex) {
            plugin.getLogger().log(Level.SEVERE, "Module '" + module.getId()
                    + "' threw while toggling to enabled=" + enabled + ". Reverting state.", ex);
            module.setEnabledState(wasEnabled);
            return;
        }

        if (persist) {
            FileConfiguration cfg = plugin.getConfig();
            cfg.set("modules." + module.getId() + ".enabled", enabled);
            plugin.saveConfig();
        }

        if (plugin.getConfig().getBoolean("settings.log-toggle-to-console", true)) {
            plugin.getLogger().info("Module '" + module.getDisplayName() + "' is now "
                    + (enabled ? "ENABLED" : "DISABLED") + ".");
        }
    }

    private void registerListeners(FeatureModule module) {
        for (Listener listener : module.getListeners()) {
            Bukkit.getPluginManager().registerEvents(listener, plugin);
        }
    }

    private void unregisterListeners(FeatureModule module) {
        for (Listener listener : module.getListeners()) {
            HandlerList.unregisterAll(listener);
        }
    }

    private void registerCommands(FeatureModule module) {
        Object executor = module.getExecutor();
        if (executor == null || !(executor instanceof CommandExecutor ce)) return;

        if (module.getPrimaryCommand() != null) {
            commandRegistrar.bind(module.getPrimaryCommand(), ce);
        }
        for (String secondary : module.getSecondaryCommands()) {
            commandRegistrar.bind(secondary, ce);
        }
    }

    private void unregisterCommands(FeatureModule module) {
        if (module.getExecutor() == null) return;

        if (module.getPrimaryCommand() != null) {
            commandRegistrar.unbind(module.getPrimaryCommand());
        }
        for (String secondary : module.getSecondaryCommands()) {
            commandRegistrar.unbind(secondary);
        }
    }

    /** Cleanly tears down every module, used from {@link PluginMain#onDisable()}. */
    public void shutdown() {
        for (FeatureModule module : modules.values()) {
            if (module.isEnabled()) {
                try {
                    unregisterCommands(module);
                    unregisterListeners(module);
                    module.onDisable();
                } catch (Exception ex) {
                    plugin.getLogger().log(Level.WARNING, "Error shutting down module '" + module.getId() + "'", ex);
                }
            }
        }
    }

    public Map<String, FeatureModule> getModules() {
        return modules;
    }

    public Optional<FeatureModule> get(String id) {
        return Optional.ofNullable(modules.get(id));
    }
}
