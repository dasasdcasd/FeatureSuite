package com.devkit.features.module.impl;

import com.devkit.features.PluginMain;
import com.devkit.features.module.AbstractFeatureModule;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * "Recording Mode" - a one-command toggle content creators flip on before
 * they start capturing footage. While a player is in recording mode:
 * <ul>
 *     <li>Their own join/quit broadcasts are suppressed server-wide (configurable)</li>
 *     <li>Raw coordinate-looking substrings they type in chat get redacted</li>
 *     <li>They get a persistent actionbar reminder that recording mode is on</li>
 * </ul>
 * This is intentionally self-contained: the listener and command are both
 * inner classes so the whole feature - GUI entry, config keys, listener,
 * command - lives in one file, matching the "one module = one file" pattern
 * the rest of the suite follows.
 */
public final class RecordingSessionModule extends AbstractFeatureModule {

    // Matches things like "123, 64, -789" or "x:123 y:64 z:-789" typed in chat.
    private static final Pattern COORD_PATTERN =
            Pattern.compile("-?\\d{1,6}\\s*[,/]\\s*-?\\d{1,4}\\s*[,/]\\s*-?\\d{1,6}");

    private final Set<UUID> activeRecorders = ConcurrentHashMap.newKeySet();
    private final RecordingListener listener = new RecordingListener();
    private final RecordingCommand executor = new RecordingCommand();

    public RecordingSessionModule(PluginMain plugin) {
        super(plugin,
                "recording",
                "Recording Mode",
                List.of("Clean HUD/chat state for", "content creators."),
                Material.OBSERVER,
                "recsession",
                "plugin.feature.recording");
    }

    @Override
    public void onEnable() {
        // Nothing to warm up - state lives in `activeRecorders` and is
        // intentionally NOT persisted across restarts (recording sessions
        // are per-session by design).
    }

    @Override
    public void onDisable() {
        activeRecorders.clear();
    }

    @Override
    public List<Listener> getListeners() {
        return List.of(listener);
    }

    @Override
    public Object getExecutor() {
        return executor;
    }

    private boolean toggle(UUID uuid) {
        if (activeRecorders.remove(uuid)) {
            return false;
        }
        activeRecorders.add(uuid);
        return true;
    }

    // ---------------------------------------------------------------
    //  Command: /recsession [on|off]
    // ---------------------------------------------------------------
    private final class RecordingCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Only players can toggle recording mode.");
                return true;
            }
            if (!player.hasPermission("plugin.admin") && !player.hasPermission(getPermission())) {
                player.sendMessage(Component.text("You do not have permission to use recording mode.", NamedTextColor.RED));
                return true;
            }

            boolean targetState;
            if (args.length >= 1) {
                if (args[0].equalsIgnoreCase("on")) targetState = true;
                else if (args[0].equalsIgnoreCase("off")) targetState = false;
                else {
                    player.sendMessage(Component.text("Usage: /recsession [on|off]", NamedTextColor.RED));
                    return true;
                }
                if (targetState) activeRecorders.add(player.getUniqueId());
                else activeRecorders.remove(player.getUniqueId());
            } else {
                targetState = toggle(player.getUniqueId());
            }

            player.sendMessage(Component.text("Recording mode: ", NamedTextColor.GRAY)
                    .append(Component.text(targetState ? "ON" : "OFF",
                            targetState ? NamedTextColor.GREEN : NamedTextColor.RED)));
            return true;
        }
    }

    // ---------------------------------------------------------------
    //  Listener: chat redaction + join/quit suppression + actionbar
    // ---------------------------------------------------------------
    private final class RecordingListener implements Listener {

        @EventHandler
        public void onJoin(PlayerJoinEvent event) {
            Player player = event.getPlayer();
            if (activeRecorders.contains(player.getUniqueId())
                    && plugin.getConfig().getBoolean("modules.recording.suppress-join-quit-broadcast", true)) {
                event.joinMessage(null);
            }
            if (activeRecorders.contains(player.getUniqueId())) {
                String msg = plugin.getConfig().getString("modules.recording.clean-actionbar-message",
                        "&aRecording mode active");
                player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                        .legacyAmpersand().deserialize(msg));
            }
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent event) {
            Player player = event.getPlayer();
            if (activeRecorders.contains(player.getUniqueId())
                    && plugin.getConfig().getBoolean("modules.recording.suppress-join-quit-broadcast", true)) {
                event.quitMessage(null);
            }
        }

        @EventHandler
        public void onChat(AsyncChatEvent event) {
            Player player = event.getPlayer();
            if (!activeRecorders.contains(player.getUniqueId())) return;
            if (!plugin.getConfig().getBoolean("modules.recording.hide-coordinates-in-chat", true)) return;

            String plain = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
                    .plainText().serialize(event.originalMessage());

            if (COORD_PATTERN.matcher(plain).find()) {
                String redacted = COORD_PATTERN.matcher(plain).replaceAll("[coords hidden]");
                event.message(Component.text(redacted));
                player.sendMessage(Component.text("Coordinates in your message were redacted (recording mode).",
                        NamedTextColor.YELLOW));
            }
        }
    }
}
