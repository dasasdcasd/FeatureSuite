package com.devkit.features.module.impl;

import com.devkit.features.PluginMain;
import com.devkit.features.module.AbstractFeatureModule;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Complete-invisibility vanish: hides the player from every online player
 * (and every player who joins afterwards), removes them from the tab list,
 * and mutes their join/quit broadcast in favour of a staff-only notice.
 * <p>
 * State is intentionally in-memory only (a server restart should never
 * leave a staff member permanently invisible), which is why, unlike most
 * modules, {@link #onDisable()} force-unvanishes everyone rather than just
 * clearing bookkeeping.
 */
public final class VanishModule extends AbstractFeatureModule {

    private final Set<UUID> vanished = ConcurrentHashMap.newKeySet();
    private final VanishListener listener = new VanishListener();
    private final VanishCommand executor = new VanishCommand();

    public VanishModule(PluginMain plugin) {
        super(plugin,
                "vanish",
                "Vanish",
                List.of("Full invisibility: hidden from", "players and the tab list."),
                Material.POTION,
                "vanish",
                "plugin.feature.vanish");
    }

    @Override
    public void onEnable() {
        // no warm-up needed
    }

    @Override
    public void onDisable() {
        // Never leave someone stuck invisible just because an admin
        // disabled the module from the GUI mid-session.
        for (UUID uuid : vanished) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) unvanish(player);
        }
        vanished.clear();
    }

    @Override
    public List<Listener> getListeners() {
        return List.of(listener);
    }

    @Override
    public Object getExecutor() {
        return executor;
    }

    public boolean isVanished(UUID uuid) {
        return vanished.contains(uuid);
    }

    private void vanish(Player player) {
        vanished.add(player.getUniqueId());
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (!online.equals(player)) {
                online.hidePlayer(plugin, player);
            }
        }
        if (plugin.getConfig().getBoolean("modules.vanish.hide-from-tab", true)) {
            // hidePlayer() above already removes the tab-list entry for
            // every currently-online viewer; blanking the name here is a
            // fallback for plugins/clients that render list names outside
            // the standard PlayerInfo packet.
            player.setPlayerListName("");
        }
        // Cheap "no footsteps/particles announce me" nicety while vanished.
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
        player.sendMessage(Component.text("You are now vanished.", NamedTextColor.GRAY));
    }

    private void unvanish(Player player) {
        vanished.remove(player.getUniqueId());
        for (Player online : Bukkit.getOnlinePlayers()) {
            online.showPlayer(plugin, player);
        }
        player.setPlayerListName(player.getName());
        player.removePotionEffect(PotionEffectType.INVISIBILITY);
        player.sendMessage(Component.text("You are no longer vanished.", NamedTextColor.GRAY));
    }

    // ---------------------------------------------------------------
    //  Command: /vanish [player]
    // ---------------------------------------------------------------
    private final class VanishCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            Player target;
            if (args.length >= 1) {
                if (!sender.hasPermission("plugin.admin")) {
                    sender.sendMessage(Component.text("You can only vanish yourself.", NamedTextColor.RED));
                    return true;
                }
                target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    sender.sendMessage(Component.text("Player not found or offline.", NamedTextColor.RED));
                    return true;
                }
            } else if (sender instanceof Player self) {
                target = self;
            } else {
                sender.sendMessage("Console must specify a player: /vanish <player>");
                return true;
            }

            if (!target.hasPermission("plugin.admin") && !target.hasPermission(getPermission())) {
                sender.sendMessage(Component.text(target.getName() + " lacks the vanish permission.", NamedTextColor.RED));
                return true;
            }

            if (vanished.contains(target.getUniqueId())) {
                unvanish(target);
            } else {
                vanish(target);
            }
            return true;
        }
    }

    // ---------------------------------------------------------------
    //  Listener: keep late joiners from seeing vanished players,
    //  and swap their join/quit broadcast for a staff-only notice.
    // ---------------------------------------------------------------
    private final class VanishListener implements Listener {

        @EventHandler
        public void onJoin(PlayerJoinEvent event) {
            Player joined = event.getPlayer();
            // Hide every already-vanished player from the newcomer.
            for (UUID uuid : vanished) {
                Player vanishedPlayer = Bukkit.getPlayer(uuid);
                if (vanishedPlayer != null && !vanishedPlayer.equals(joined)) {
                    joined.hidePlayer(plugin, vanishedPlayer);
                }
            }
            // If the joining player themself was vanished pre-restart... they
            // aren't (state is in-memory only, see class javadoc) - nothing to do.
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent event) {
            Player player = event.getPlayer();
            if (vanished.remove(player.getUniqueId())) {
                event.quitMessage(null);
                String fmt = plugin.getConfig().getString("modules.vanish.vanish-quit-message",
                        "&7[-] {player} (vanished)");
                notifyStaff(fmt.replace("{player}", player.getName()));
            }
        }

        private void notifyStaff(String legacyText) {
            Component msg = LegacyComponentSerializer.legacyAmpersand().deserialize(legacyText);
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.hasPermission("plugin.admin") || staff.hasPermission("plugin.feature.vanish")) {
                    staff.sendMessage(msg);
                }
            }
        }
    }
}
